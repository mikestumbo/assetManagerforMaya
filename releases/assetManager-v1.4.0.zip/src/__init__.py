# Asset Manager v1.3.0 - Source Package
# Enterprise Modular Service Architecture (EMSA)
